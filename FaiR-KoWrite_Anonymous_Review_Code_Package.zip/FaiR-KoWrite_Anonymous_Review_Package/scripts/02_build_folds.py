#!/usr/bin/env python3
from pathlib import Path
import argparse,pandas as pd
from fairkowrite.utils.io import read_jsonl
from sklearn.model_selection import StratifiedGroupKFold

def main():
 p=argparse.ArgumentParser(); p.add_argument('--essays',default='data/processed/kh_essays.jsonl'); p.add_argument('--output',default='manifests/generated_folds'); p.add_argument('--seed',type=int,default=2026); a=p.parse_args(); rows=read_jsonl(a.essays); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
 df=pd.DataFrame(rows); sg=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=a.seed); df['outer_fold']=0
 for fold,(_,te) in enumerate(sg.split(df,df.level,groups=df.writer_id),1): df.loc[te,'outer_fold']=fold
 writers=df[['writer_id','outer_fold']].drop_duplicates(); assert writers.writer_id.nunique()==len(writers); writers.to_csv(out/'writer_grouped_outer_folds.csv',index=False); df[['essay_id','writer_id','level','outer_fold']].to_csv(out/'essay_outer_folds.csv',index=False)
 print(df.groupby(['outer_fold','level']).size().unstack(fill_value=0))
if __name__=='__main__': main()
