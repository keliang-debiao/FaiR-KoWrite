from __future__ import annotations
import torch

def batch(seed=2026,b=8,t=4,l=12,fl=24):
 g=torch.Generator().manual_seed(seed)
 return {"inputs":{"semantic_ids":torch.randint(1,100,(b,t,l),generator=g),"semantic_mask":torch.ones((b,t,l),dtype=torch.bool),"form_ids":torch.randint(1,330,(b,t,fl),generator=g),"form_mask":torch.ones((b,t,fl),dtype=torch.bool),"sentence_mask":torch.ones((b,t),dtype=torch.bool),"grl":.5},"y":torch.arange(b)%6,"source_y":torch.arange(b)%2,"l1_y":torch.arange(b)%4}
