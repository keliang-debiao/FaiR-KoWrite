#!/usr/bin/env python3
from pathlib import Path
import argparse
import json
import urllib.request
from fairkowrite.utils.hashing import sha256_file

URLS = {
    "train": "https://raw.githubusercontent.com/UniversalDependencies/UD_Korean-KSL/master/ko_ksl-ud-train.conllu",
    "dev": "https://raw.githubusercontent.com/UniversalDependencies/UD_Korean-KSL/master/ko_ksl-ud-dev.conllu",
    "test": "https://raw.githubusercontent.com/UniversalDependencies/UD_Korean-KSL/master/ko_ksl-ud-test.conllu",
}
EXPECTED = {
    "train": "80659ebe423e6b39fdcd4a5eed3251de5f78b3ddede837f69cf98934e1f5c8bd",
    "dev": "b986979df5137ab1554e7c38a0d7257ce7182a7e76eb82b586610733a289e15b",
    "test": "62574d11b83f62217494a53fd2a7cbf75b7fc3fe5df74021a91e66df65149033",
}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="data/raw/ud_ksl")
    args = parser.parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    report = {}
    for split, url in URLS.items():
        dest = out / f"ko_ksl-ud-{split}.conllu"
        urllib.request.urlretrieve(url, dest)
        digest = sha256_file(dest)
        report[split] = {"path": str(dest), "sha256": digest, "expected": EXPECTED[split], "ok": digest == EXPECTED[split]}
        if digest != EXPECTED[split]:
            raise SystemExit(f"Hash mismatch for {split}")
    (out / "download_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
