from __future__ import annotations
import torch
from torch import nn
from .mamba import SequenceMixer

class BidirectionalDiscourse(nn.Module):
    def __init__(self,dim:int=384,layers:int=2,dropout:float=.1):
        super().__init__(); self.fwd=nn.ModuleList([SequenceMixer(dim) for _ in range(layers)]); self.rev=nn.ModuleList([SequenceMixer(dim) for _ in range(layers)])
        self.merge=nn.Sequential(nn.Linear(dim*2,dim),nn.LayerNorm(dim),nn.Dropout(dropout)); self.query=nn.Parameter(torch.randn(dim)/dim**.5)
    def forward(self,x:torch.Tensor,mask:torch.Tensor)->torch.Tensor:
        a=x
        for m in self.fwd:a=m(a)
        b=torch.flip(x,[1])
        for m in self.rev:b=m(b)
        b=torch.flip(b,[1]); h=self.merge(torch.cat([a,b],-1))
        score=torch.einsum('btd,d->bt',h,self.query).masked_fill(~mask,-1e4)
        w=torch.softmax(score,-1).unsqueeze(-1)
        return (h*w).sum(1)
