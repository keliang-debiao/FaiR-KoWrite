#!/usr/bin/env python3
"""Baseline run planner and transparent TF-IDF executor."""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
from fairkowrite.models.baselines import TfidfOrdinalBaseline
from fairkowrite.evaluation.metrics import metric_bundle
from fairkowrite.utils.io import read_jsonl

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="tfidf_ordinal", choices=["tfidf_ordinal", "bilstm_attention", "han", "mbert_corn", "klue_roberta_corn", "xlm_roberta_corn", "granite_r2_corn", "qwen3_corn"])
    parser.add_argument("--essays", default="data/processed/kh_essays.jsonl")
    parser.add_argument("--folds", default="manifests/essay_outer_folds.csv")
    parser.add_argument("--outer-fold", type=int, default=1)
    args = parser.parse_args()
    if args.model != "tfidf_ordinal":
        print(json.dumps({"model": args.model, "status": "FULL_NEURAL_RUN_REQUIRED", "shared_protocol": "configs/main.yaml"}, indent=2))
        return
    rows = pd.DataFrame(read_jsonl(args.essays))
    folds = pd.read_csv(args.folds).rename(columns={"fold": "outer_fold"})
    rows = rows.merge(folds[["essay_id", "outer_fold"]], on="essay_id", how="inner")
    label_map = {"A1": 0, "A2": 1, "B1": 2, "B2": 3, "C1": 4, "C2": 5}
    y = rows.level.map(label_map).to_numpy()
    train = rows.outer_fold != args.outer_fold
    test = ~train
    model = TfidfOrdinalBaseline().fit(rows.loc[train, "text"].tolist(), y[train])
    probs = model.predict_proba(rows.loc[test, "text"].tolist())
    report = metric_bundle(y[test], probs)
    report.update({"model": args.model, "outer_fold": args.outer_fold, "n_test": int(test.sum())})
    out = Path("outputs/baselines")
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{args.model}_fold{args.outer_fold}.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
