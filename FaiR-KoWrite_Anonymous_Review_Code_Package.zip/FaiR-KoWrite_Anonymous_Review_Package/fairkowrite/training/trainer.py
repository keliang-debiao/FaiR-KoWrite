from __future__ import annotations
import torch
from torch.optim import AdamW
from fairkowrite.models.groupdro import LevelGroupDRO
from .losses import joint_loss

class Trainer:
    def __init__(self,model,lr=3e-4,device='cpu'):
        self.model=model.to(device); self.device=device; self.opt=AdamW(model.parameters(),lr=lr,weight_decay=.01); self.groupdro=LevelGroupDRO().to(device)
    def step(self,batch):
        self.model.train(); self.opt.zero_grad(set_to_none=True)
        out=self.model(**{k:v.to(self.device) if hasattr(v,'to') else v for k,v in batch['inputs'].items()})
        loss,details=joint_loss(out,batch['y'].to(self.device),self.groupdro,batch.get('source_y',None).to(self.device) if batch.get('source_y') is not None else None,batch.get('l1_y',None).to(self.device) if batch.get('l1_y') is not None else None)
        loss.backward(); torch.nn.utils.clip_grad_norm_(self.model.parameters(),1.0); self.opt.step()
        details['total']=float(loss.detach()); return details,out
