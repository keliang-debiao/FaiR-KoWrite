# Data placement and licensing

Raw learner text is not redistributed. Run `scripts/00_download_and_verify.py` for the pinned public UD Korean-KSL release. The script verifies the manuscript SHA-256 hashes before reconstruction.

Place the independently obtained KoLLA v2.0 mapping at `data/external/kolla_v2.jsonl` with fields documented in `schemas/kolla.schema.json`. KoLLA is never used for fitting, model selection, calibration, or threshold selection.

Derived text-bearing files under `data/processed/` should remain private unless source licenses permit redistribution. For anonymous review, upload manifests, hashes, schemas, and predictions keyed by anonymized essay IDs rather than raw learner text.
