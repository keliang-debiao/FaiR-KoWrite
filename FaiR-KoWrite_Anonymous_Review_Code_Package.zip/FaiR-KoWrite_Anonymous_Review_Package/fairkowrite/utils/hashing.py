from __future__ import annotations
from pathlib import Path
import hashlib

def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        while chunk := f.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
