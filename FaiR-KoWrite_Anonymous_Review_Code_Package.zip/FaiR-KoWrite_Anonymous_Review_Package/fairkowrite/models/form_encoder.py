from __future__ import annotations
import torch
from torch import nn
from .mamba import SequenceMixer

class FormEncoder(nn.Module):
    def __init__(self,vocab_size:int=331,emb_dim:int=192,out_dim:int=384,layers:int=2,dropout:float=.1):
        super().__init__(); self.emb=nn.Embedding(vocab_size,emb_dim,padding_idx=0)
        self.layers=nn.ModuleList([SequenceMixer(emb_dim) for _ in range(layers)])
        self.attn=nn.Linear(emb_dim,1); self.proj=nn.Sequential(nn.Linear(emb_dim,out_dim),nn.LayerNorm(out_dim),nn.Dropout(dropout))
    def forward(self,ids:torch.Tensor,mask:torch.Tensor)->torch.Tensor:
        x=self.emb(ids)
        for layer in self.layers: x=layer(x)
        score=self.attn(x).squeeze(-1).masked_fill(~mask,-1e4)
        a=torch.softmax(score,dim=-1).unsqueeze(-1)
        return self.proj((a*x).sum(1))
