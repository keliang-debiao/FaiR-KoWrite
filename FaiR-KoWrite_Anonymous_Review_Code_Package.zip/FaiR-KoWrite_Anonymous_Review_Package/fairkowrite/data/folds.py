from __future__ import annotations
from pathlib import Path
import pandas as pd

def load_writer_folds(path: str | Path) -> pd.DataFrame:
    df=pd.read_csv(path)
    if "outer_fold" not in df.columns and "fold" in df.columns:
        df=df.rename(columns={"fold":"outer_fold"})
    required={"writer_id","outer_fold"}
    if not required.issubset(df.columns):
        raise ValueError(f"Fold manifest missing columns: {required-set(df.columns)}")
    if df.writer_id.duplicated().any():
        raise ValueError("A writer appears more than once in fold manifest")
    if not set(df.outer_fold).issubset({1,2,3,4,5}):
        raise ValueError("outer_fold must be 1..5")
    return df

def attach_folds(essays: list[dict], manifest: pd.DataFrame) -> list[dict]:
    mapping=dict(zip(manifest.writer_id.astype(str), manifest.outer_fold.astype(int)))
    out=[]
    for e in essays:
        if e["writer_id"] not in mapping: raise KeyError(f"Missing writer {e['writer_id']}")
        row=dict(e); row["outer_fold"]=mapping[e["writer_id"]]; out.append(row)
    return out

def assert_no_writer_leakage(rows: list[dict]) -> None:
    seen={}
    for r in rows:
        w=str(r["writer_id"]); f=int(r["outer_fold"])
        if w in seen and seen[w]!=f: raise AssertionError(f"Writer leakage: {w}")
        seen[w]=f
