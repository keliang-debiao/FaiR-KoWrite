# Full-model integration boundary

The package supplies the scientifically material data, architecture, objective, evaluation, calibration, shift-diagnostic, robustness, and statistical logic. Full GPU execution additionally requires licensed/raw corpus placement, immutable third-party model snapshots, and the compute environment documented under `environment/`.

`03_train_cv.py` intentionally refuses to produce fabricated measurements. Integrators should connect the repository dataset class to the institution's storage and scheduler, preserve the output schemas, and leave every simulated artifact marked. A valid full run must emit checkpoints, per-seed held-out probabilities, cross-fitted validation logits, fold-specific ARG representations, and immutable run metadata.
