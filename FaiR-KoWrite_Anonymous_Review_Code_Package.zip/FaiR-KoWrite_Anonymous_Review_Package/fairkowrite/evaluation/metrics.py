from __future__ import annotations
import numpy as np
from sklearn.metrics import cohen_kappa_score, f1_score, balanced_accuracy_score, accuracy_score

def expected_score(probs): return np.asarray(probs)@np.arange(np.asarray(probs).shape[1])
def metric_bundle(y,probs):
    y=np.asarray(y,dtype=int); probs=np.asarray(probs); pred=probs.argmax(1); exp=expected_score(probs)
    return {
      "qwk":float(cohen_kappa_score(y,pred,weights='quadratic')),
      "macro_f1":float(f1_score(y,pred,average='macro',zero_division=0)),
      "balanced_accuracy":float(balanced_accuracy_score(y,pred)),
      "mae":float(np.mean(np.abs(y-exp))),
      "exact_accuracy":float(accuracy_score(y,pred)),
      "within_one":float(np.mean(np.abs(y-pred)<=1)),
      "distance_ge_2":float(np.mean(np.abs(y-pred)>=2))
    }
def ece(y,probs,n_bins=15):
    y=np.asarray(y); p=np.asarray(probs); conf=p.max(1); pred=p.argmax(1)
    edges=np.quantile(conf,np.linspace(0,1,n_bins+1)); total=0.
    for lo,hi in zip(edges[:-1],edges[1:]):
        m=(conf>=lo)&(conf<=hi if hi==edges[-1] else conf<hi)
        if m.any(): total+=m.mean()*abs((pred[m]==y[m]).mean()-conf[m].mean())
    return float(total)
