from __future__ import annotations
import torch
from torch import nn
import torch.nn.functional as F

class CORNHead(nn.Module):
    def __init__(self,dim:int=384,num_classes:int=6):
        super().__init__(); self.num_classes=num_classes; self.fc=nn.Linear(dim,num_classes-1)
    def forward(self,z): return self.fc(z)
    @staticmethod
    def probabilities(logits:torch.Tensor)->torch.Tensor:
        q=torch.sigmoid(logits)
        gt=torch.cumprod(q,dim=-1)
        probs=[1-gt[:,0]]
        for k in range(1,gt.shape[1]): probs.append(gt[:,k-1]-gt[:,k])
        probs.append(gt[:,-1])
        p=torch.stack(probs,-1).clamp_min(1e-8)
        return p/p.sum(-1,keepdim=True)
    @staticmethod
    def loss(logits:torch.Tensor,y:torch.Tensor,reduction='none')->torch.Tensor:
        losses=[]
        for k in range(logits.shape[1]):
            active=y>=k
            if active.any():
                target=(y[active]>k).float()
                l=F.binary_cross_entropy_with_logits(logits[active,k],target,reduction='none')
                full=torch.zeros_like(y,dtype=logits.dtype); full[active]=l; losses.append(full)
        out=torch.stack(losses).sum(0)/torch.stack([(y>=k).float() for k in range(logits.shape[1])]).sum(0).clamp_min(1)
        return out.mean() if reduction=='mean' else out
