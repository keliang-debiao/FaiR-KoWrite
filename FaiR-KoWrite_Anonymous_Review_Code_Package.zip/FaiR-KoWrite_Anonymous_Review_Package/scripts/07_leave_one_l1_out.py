#!/usr/bin/env python3
import argparse,json

def main():
 p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/main.yaml'); a=p.parse_args(); plan=[{"held_out_l1":x,"training_arg_l1":[y for y in ['CHN','CZH','ENG','JPN'] if y!=x],"requires_retraining":True} for x in ['CHN','CZH','ENG','JPN']]; print(json.dumps(plan,indent=2))
if __name__=='__main__': main()
