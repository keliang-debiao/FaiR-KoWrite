#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import torch
from fairkowrite.models.model import FaiRKoWrite
from fairkowrite.training.trainer import Trainer
from fairkowrite.evaluation.metrics import metric_bundle, ece
from fairkowrite.evaluation.calibration import fit_temperature, apply_temperature, uncertainty, selective_metrics
from scripts._synthetic import batch

def main() -> None:
    torch.set_num_threads(1)
    output_dir = Path("outputs/smoke")
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = Path("logs/smoke/smoke.log")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    model = FaiRKoWrite(semantic_mode="tiny", dim=64)
    trainer = Trainer(model, lr=1e-3)
    smoke_batch = batch()
    history = []
    for _ in range(3):
        details, output = trainer.step(smoke_batch)
        history.append(details)
    probs = output["probs"].detach().numpy()
    labels = smoke_batch["y"].numpy()
    logits = np.log(probs.clip(1e-8, 1))
    temperature = fit_temperature(logits, labels)
    calibrated = apply_temperature(logits, temperature)
    u = uncertainty(np.stack([calibrated, calibrated * 0.999 + 0.001 / 6]))
    report = {
        "status": "PASS",
        "SIMULATED_REFERENCE_LOG": False,
        "synthetic_non_learner_data": True,
        "loss_history": history,
        "probability_row_sums": output["probs"].sum(-1).detach().tolist(),
        "temperature": temperature,
        "ece": ece(labels, calibrated),
        "metrics": metric_bundle(labels, calibrated),
        "selective": selective_metrics(labels, calibrated, u, float(np.quantile(u, 0.8)), metric_bundle),
        "groupdro_weights": trainer.groupdro.weights.detach().tolist(),
        "mixer_backends": sorted({m.backend for m in model.modules() if hasattr(m, "backend")}),
    }
    (output_dir / "smoke_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    log_path.write_text("REAL_SMOKE_LOG=TRUE\nSYNTHETIC_NON_LEARNER_DATA=TRUE\n" + json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
