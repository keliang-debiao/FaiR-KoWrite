#!/usr/bin/env python3
from pathlib import Path
import argparse,pandas as pd,json
from fairkowrite.evaluation.statistics import writer_cluster_bootstrap,paired_writer_permutation

def main():
 p=argparse.ArgumentParser(); p.add_argument('--a',required=True); p.add_argument('--b'); p.add_argument('--config',default='configs/main.yaml'); p.add_argument('--bootstrap',type=int,default=5000); p.add_argument('--permutations',type=int,default=10000); a=p.parse_args(); da=pd.read_csv(a.a); cols=[f'prob_{i}' for i in range(6)]; rep={"qwk_ci":writer_cluster_bootstrap(da.label,da[cols],da.writer_id,a.bootstrap)}
 if a.b:
  db=pd.read_csv(a.b); rep['paired']=paired_writer_permutation(da.label,da[cols],db[cols],da.writer_id,a.permutations)
 print(json.dumps(rep,indent=2))
if __name__=='__main__': main()
