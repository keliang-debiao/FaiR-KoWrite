from __future__ import annotations
import torch
from torch import nn
from .semantic import TinySemanticEncoder,HFSemanticEncoder
from .form_encoder import FormEncoder
from .fusion import CrossGatedBilinearFusion
from .discourse import BidirectionalDiscourse
from .corn import CORNHead
from .adversarial import Discriminator

class FaiRKoWrite(nn.Module):
    def __init__(self,semantic_mode='tiny',semantic_model=None,semantic_revision=None,dim=384,form_vocab=331):
        super().__init__()
        self.semantic=TinySemanticEncoder(out_dim=dim) if semantic_mode=='tiny' else HFSemanticEncoder(semantic_model,semantic_revision,dim)
        self.form=FormEncoder(vocab_size=form_vocab,emb_dim=min(192,dim),out_dim=dim)
        self.fusion=CrossGatedBilinearFusion(dim)
        self.discourse=BidirectionalDiscourse(dim)
        self.corn=CORNHead(dim)
        self.source_disc=Discriminator(dim,2); self.l1_disc=Discriminator(dim,4)
    def forward(self,semantic_ids,semantic_mask,form_ids,form_mask,sentence_mask,grl=1.0):
        b,t,l=semantic_ids.shape
        s=self.semantic(semantic_ids.reshape(b*t,l),semantic_mask.reshape(b*t,l)).reshape(b,t,-1)
        bf,tf,lf=form_ids.shape
        f=self.form(form_ids.reshape(bf*tf,lf),form_mask.reshape(bf*tf,lf)).reshape(bf,tf,-1)
        h,g=self.fusion(s.reshape(-1,s.shape[-1]),f.reshape(-1,f.shape[-1])); h=h.reshape(b,t,-1); g=g.reshape(b,t,-1)
        z=self.discourse(h,sentence_mask)
        logits=self.corn(z); probs=self.corn.probabilities(logits)
        return {"logits":logits,"probs":probs,"z":z,"gate":g,"source_logits":self.source_disc(z,grl),"l1_logits":self.l1_disc(z,grl)}
