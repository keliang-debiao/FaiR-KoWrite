#!/usr/bin/env python3
from pathlib import Path
import argparse,pandas as pd,numpy as np,json
from fairkowrite.evaluation.shift import writer_heldout_probe,rbf_mmd

def main():
 p=argparse.ArgumentParser(); p.add_argument('--representations',default='outputs/arg/fold_specific_representations.csv'); p.add_argument('--config',default='configs/main.yaml'); a=p.parse_args(); path=Path(a.representations)
 if not path.exists(): raise SystemExit('Fold-specific ARG representations required. Do not aggregate latent vectors across independently trained encoders.')
 df=pd.read_csv(path); z=df.filter(regex='^z_').to_numpy(); rep=writer_heldout_probe(z,df.l1,df.writer_id); groups=sorted(df.l1.unique()); rep['mean_pairwise_mmd']=float(np.mean([rbf_mmd(z[df.l1==a],z[df.l1==b]) for i,a in enumerate(groups) for b in groups[i+1:]])); print(json.dumps(rep,indent=2))
if __name__=='__main__': main()
