from __future__ import annotations
import numpy as np
from .metrics import metric_bundle

def writer_cluster_bootstrap(y,probs,writers,n=5000,seed=2026):
    rng=np.random.default_rng(seed); y=np.asarray(y); probs=np.asarray(probs); writers=np.asarray(writers); uniq=np.unique(writers); vals=[]
    for _ in range(n):
        draw=rng.choice(uniq,len(uniq),replace=True); idx=np.concatenate([np.flatnonzero(writers==w) for w in draw]); vals.append(metric_bundle(y[idx],probs[idx])['qwk'])
    return [float(np.quantile(vals,.025)),float(np.quantile(vals,.975))]
def paired_writer_permutation(y,pa,pb,writers,n=10000,seed=2026):
    rng=np.random.default_rng(seed); y=np.asarray(y); pa=np.asarray(pa); pb=np.asarray(pb); writers=np.asarray(writers); uniq=np.unique(writers)
    observed=metric_bundle(y,pa)['qwk']-metric_bundle(y,pb)['qwk']; vals=[]
    for _ in range(n):
        swap=set(uniq[rng.random(len(uniq))<.5]); mask=np.array([w in swap for w in writers]); a=pa.copy(); b=pb.copy(); a[mask],b[mask]=pb[mask],pa[mask]; vals.append(metric_bundle(y,a)['qwk']-metric_bundle(y,b)['qwk'])
    p=(1+sum(abs(v)>=abs(observed) for v in vals))/(n+1)
    return {"delta_qwk":float(observed),"p":float(p)}
def holm(p_values):
    p=np.asarray(p_values); order=np.argsort(p); out=np.empty_like(p,float); running=0.
    m=len(p)
    for rank,i in enumerate(order): running=max(running,(m-rank)*p[i]); out[i]=min(running,1.)
    return out.tolist()
