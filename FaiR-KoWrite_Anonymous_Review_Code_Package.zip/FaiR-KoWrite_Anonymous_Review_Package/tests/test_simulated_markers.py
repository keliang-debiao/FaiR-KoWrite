from pathlib import Path

def test_all_simulated_logs_marked():
 files=list(Path('logs/simulated').glob('*.log')); assert files
 for p in files:
  t=p.read_text(); assert 'SIMULATED_REFERENCE_LOG=TRUE' in t; assert 'NOT_MEASURED_OUTPUT=TRUE' in t; assert 'PURPOSE=AI_WORKFLOW_GUIDANCE_ONLY' in t
