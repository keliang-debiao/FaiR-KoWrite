#!/usr/bin/env python3
from pathlib import Path
import hashlib,sys

def main():
 root=Path(__file__).resolve().parents[1]; bad=[]
 for line in (root/'PACKAGE_CHECKSUMS.sha256').read_text().splitlines():
  if not line.strip():continue
  expected,rel=line.split('  ',1); p=root/rel
  if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected: bad.append(rel)
 print('CHECKSUMS PASS' if not bad else 'CHECKSUMS FAIL: '+','.join(bad)); sys.exit(bool(bad))
if __name__=='__main__': main()
