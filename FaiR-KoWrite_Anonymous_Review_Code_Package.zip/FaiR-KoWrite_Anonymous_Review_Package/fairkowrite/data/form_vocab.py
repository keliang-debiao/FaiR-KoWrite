from __future__ import annotations
import unicodedata
import torch

SPECIAL=["<pad>","<unk>","<bos>","<eos>","<space>","<punct>","<ending>","<newline>"]
JAMO=[chr(c) for c in range(0x1100,0x1113)]+[chr(c) for c in range(0x1161,0x1176)]+[chr(c) for c in range(0x11A8,0x11C3)]
BYTE=[f"<b{i}>" for i in range(256)]
VOCAB=(SPECIAL+JAMO+BYTE)[:331]
TOKEN_TO_ID={t:i for i,t in enumerate(VOCAB)}

class JamoByteTokenizer:
    def __init__(self,max_length:int=2048): self.max_length=max_length
    @property
    def vocab_size(self): return len(VOCAB)
    def tokens(self,text:str)->list[str]:
        out=["<bos>"]
        for ch in text:
            if ch.isspace(): out.append("<space>"); continue
            decomp=unicodedata.normalize("NFD",ch)
            j=[c for c in decomp if c in TOKEN_TO_ID]
            if j: out.extend(j)
            elif unicodedata.category(ch).startswith("P"): out.append("<punct>")
            else: out.extend(f"<b{b}>" for b in ch.encode("utf-8"))
        out.append("<eos>")
        return out[:self.max_length]
    def encode(self,text:str)->list[int]:
        unk=TOKEN_TO_ID["<unk>"]
        return [TOKEN_TO_ID.get(t,unk) for t in self.tokens(text)]
    def batch(self,texts:list[str])->tuple[torch.Tensor,torch.Tensor]:
        ids=[self.encode(t) for t in texts]; m=max(map(len,ids))
        x=torch.zeros((len(ids),m),dtype=torch.long); mask=torch.zeros_like(x,dtype=torch.bool)
        for i,row in enumerate(ids): x[i,:len(row)]=torch.tensor(row); mask[i,:len(row)]=True
        return x,mask
