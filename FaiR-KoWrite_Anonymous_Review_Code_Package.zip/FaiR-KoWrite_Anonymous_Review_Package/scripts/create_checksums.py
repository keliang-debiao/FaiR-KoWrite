#!/usr/bin/env python3
from pathlib import Path
import hashlib

EXCLUDE = {"PACKAGE_CHECKSUMS.sha256"}

def main() -> None:
    root = Path(__file__).resolve().parents[1]
    rows = []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if not path.is_file() or path.name in EXCLUDE or "__pycache__" in path.parts or ".pytest_cache" in path.parts:
            continue
        if relative.parts and relative.parts[0] == "outputs":
            continue
        if str(relative).startswith("logs/smoke/"):
            continue
        rows.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {relative.as_posix()}")
    (root / "PACKAGE_CHECKSUMS.sha256").write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(len(rows))

if __name__ == "__main__":
    main()
