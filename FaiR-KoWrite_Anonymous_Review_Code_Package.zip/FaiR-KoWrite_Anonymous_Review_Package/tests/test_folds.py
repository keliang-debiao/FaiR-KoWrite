import pandas as pd
from fairkowrite.data.folds import load_writer_folds

def test_reference_fold_manifest():
 df=load_writer_folds('manifests/writer_grouped_outer_folds.csv'); assert len(df)==332; assert df.writer_id.nunique()==332; assert set(df.outer_fold)=={1,2,3,4,5}
