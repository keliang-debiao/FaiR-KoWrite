#!/usr/bin/env python3
from pathlib import Path
import argparse
import collections
import json
from fairkowrite.data.conllu import read_conllu, reconstruct_essays, assign_kh_levels_from_release, exact_deduplicate_kh
from fairkowrite.utils.io import write_jsonl

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", default="data/raw/ud_ksl")
    parser.add_argument("--output-dir", default="data/processed")
    args = parser.parse_args()
    inp, out = Path(args.input_dir), Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths = [inp / f"ko_ksl-ud-{split}.conllu" for split in ("train", "dev", "test")]
    records = read_conllu(paths)
    essays = reconstruct_essays(records)
    kh = [e for e in essays if e["source"] == "KH"]
    arg = [e for e in essays if e["source"] == "ARG"]
    kh, decisions = exact_deduplicate_kh(kh)
    assign_kh_levels_from_release(kh)
    write_jsonl(out / "kh_essays.jsonl", kh)
    write_jsonl(out / "arg_essays.jsonl", arg)
    write_jsonl(out / "duplicate_decisions.jsonl", decisions)
    report = {
        "sentences": len(records),
        "kh_before": len(kh) + len(decisions),
        "kh_after": len(kh),
        "arg": len(arg),
        "kh_writers": len({e["writer_id"] for e in kh}),
        "arg_writers": len({e["writer_id"] for e in arg}),
        "levels": dict(collections.Counter(e["level"] for e in kh)),
        "kl_in_development": 0,
        "duplicate_removals": len(decisions),
    }
    expected = {"sentences": 17369, "kh_before": 3069, "kh_after": 3065, "arg": 435, "kh_writers": 332, "arg_writers": 157, "duplicate_removals": 4}
    for key, value in expected.items():
        if report[key] != value:
            raise SystemExit(f"Audit mismatch {key}: {report[key]} != {value}")
    expected_levels = {"A1": 422, "A2": 419, "B1": 443, "B2": 956, "C1": 421, "C2": 404}
    if report["levels"] != expected_levels:
        raise SystemExit(f"Level-count mismatch: {report['levels']} != {expected_levels}")
    (out / "audit_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
