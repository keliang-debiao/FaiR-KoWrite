import torch
from fairkowrite.models.corn import CORNHead

def test_corn_probabilities():
 logits=torch.randn(7,5); p=CORNHead.probabilities(logits); assert p.shape==(7,6); assert torch.allclose(p.sum(-1),torch.ones(7),atol=1e-6); assert (p>=0).all()
