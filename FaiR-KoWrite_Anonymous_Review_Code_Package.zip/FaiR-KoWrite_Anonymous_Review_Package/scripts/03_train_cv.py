#!/usr/bin/env python3
"""Full CV launcher that refuses to fabricate measurements."""
from pathlib import Path
import argparse
import json
from fairkowrite.utils.io import load_yaml

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    cfg = load_yaml(args.config)
    out = Path("outputs/cv")
    out.mkdir(parents=True, exist_ok=True)
    required = [Path(cfg["data"]["kh_essays"]), Path(cfg["data"]["arg_essays"])]
    missing = [p for p in required if not p.exists()]
    if missing:
        raise SystemExit("Missing licensed/derived data: " + ", ".join(map(str, missing)))
    if str(cfg["model"]["semantic_revision"]).startswith("RESOLVE_"):
        raise SystemExit("Resolve the immutable semantic-model revision before a full run.")
    plans = [
        {"outer_fold": fold, "seed": seed, "status": "planned", "requires_real_data": True}
        for fold in range(1, 6) for seed in cfg["seeds"]
    ]
    (out / "run_plan.json").write_text(json.dumps(plans, indent=2) + "\n", encoding="utf-8")
    if not args.execute:
        print(json.dumps({"status": "PLAN_ONLY", "runs": len(plans)}, indent=2))
        return
    raise SystemExit(
        "Execution requires institution-specific licensed-data and scheduler integration. "
        "Do not claim a run until real checkpoints and OOF prediction files are emitted."
    )

if __name__ == "__main__":
    main()
