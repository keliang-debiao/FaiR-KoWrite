#!/usr/bin/env python3
from pathlib import Path
import argparse
import json
import re
import sys

REQUIRED = [
    "README.md", "ANONYMITY.md", "REPRODUCIBILITY.md", "LICENSE", "configs/main.yaml",
    "manifests/data_sources.json", "manifests/model_revisions.json", "manifests/writer_grouped_outer_folds.csv",
    "schemas/prediction.schema.json", "scripts/run_smoke.py",
]
FORBIDDEN = [r"/Users/", r"/home/[^/]+/", r"[A-Za-z]:\\Users\\", r"api[_-]?key", r"access[_-]?token"]

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict-submission", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    errors, warnings = [], []
    for rel in REQUIRED:
        if not (root / rel).exists():
            errors.append("missing:" + rel)
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".py", ".md", ".yaml", ".yml", ".json", ".txt", ".csv", ".cff"}:
            text = path.read_text(encoding="utf-8", errors="ignore")
            if path.name != "verify_repository.py":
                for pattern in FORBIDDEN:
                    if re.search(pattern, text, re.I):
                        errors.append(f"anonymity:{path.relative_to(root)}:{pattern}")
    for path in (root / "logs/simulated").glob("*.log"):
        text = path.read_text(encoding="utf-8")
        for marker in ["SIMULATED_REFERENCE_LOG=TRUE", "NOT_MEASURED_OUTPUT=TRUE", "PURPOSE=AI_WORKFLOW_GUIDANCE_ONLY"]:
            if marker not in text:
                errors.append(f"unmarked simulated log:{path.name}")
    revisions = json.loads((root / "manifests/model_revisions.json").read_text(encoding="utf-8"))
    unresolved = [key for key, value in revisions.items() if isinstance(value, dict) and str(value.get("revision", "")).startswith("RESOLVE_")]
    if unresolved:
        warnings.append("unresolved model revisions:" + ",".join(unresolved))
    if args.strict_submission:
        if unresolved:
            errors.append("strict: unresolved model revisions")
        import pandas as pd
        generated = pd.read_csv(root / "manifests/generated_fold_profile.csv")
        target = pd.read_csv(root / "manifests/paper_outer_fold_profile.csv")
        columns = [c for c in target.columns if c in generated.columns]
        if not generated[columns].reset_index(drop=True).equals(target[columns].reset_index(drop=True)):
            errors.append("strict: reference fold profile differs from experiment-locked manuscript profile")
        if (root / "results_reference/simulated_oof_predictions.csv").exists():
            errors.append("strict: simulated predictions present")
    report = {"status": "FAIL" if errors else "PASS", "strict": args.strict_submission, "errors": errors, "warnings": warnings}
    print(json.dumps(report, indent=2))
    sys.exit(1 if errors else 0)

if __name__ == "__main__":
    main()
