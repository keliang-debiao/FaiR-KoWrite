from __future__ import annotations
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import softmax

def fit_temperature(logits,y):
    logits=np.asarray(logits,float); y=np.asarray(y,int)
    def nll(t):
        p=softmax(logits/max(float(t),1e-4),axis=1).clip(1e-12,1); return -np.log(p[np.arange(len(y)),y]).mean()
    return float(minimize_scalar(nll,bounds=(.2,5.0),method='bounded').x)
def apply_temperature(logits,t): return softmax(np.asarray(logits)/float(t),axis=1)
def uncertainty(probs_by_seed,dispersion_weight=.5):
    p=np.asarray(probs_by_seed); mean=p.mean(0)
    ent=-(mean*np.log(mean.clip(1e-12,1))).sum(-1)/np.log(mean.shape[-1])
    disp=np.sqrt(((p-mean[None])**2).mean((0,2))); disp=disp/(disp.max()+1e-12)
    return ent+dispersion_weight*disp

def selective_metrics(y,probs,u,threshold,metric_fn):
    accept=np.asarray(u)<=threshold
    out={"coverage":float(accept.mean()),"abstention":float(1-accept.mean()),"n_accepted":int(accept.sum())}
    if accept.any(): out.update(metric_fn(np.asarray(y)[accept],np.asarray(probs)[accept]))
    return out
