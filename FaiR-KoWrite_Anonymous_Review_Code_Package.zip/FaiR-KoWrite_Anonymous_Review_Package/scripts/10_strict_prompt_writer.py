#!/usr/bin/env python3
import argparse,json

def main():
 p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/main.yaml'); a=p.parse_args(); print(json.dumps({"split_unit":["writer_id","prompt_id"],"selection":"inner_only","requires_full_retraining":True,"claim":"strict prompt-and-writer transfer"},indent=2))
if __name__=='__main__': main()
