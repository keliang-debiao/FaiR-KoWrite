from __future__ import annotations
import torch
from torch import nn

class LevelGroupDRO(nn.Module):
    def __init__(self,n_groups=6,eta=.05,ema=.90,min_weight=.02,max_weight=.40):
        super().__init__(); self.eta=eta; self.ema=ema; self.min_weight=min_weight; self.max_weight=max_weight
        self.register_buffer('weights',torch.full((n_groups,),1/n_groups)); self.register_buffer('moving',torch.ones(n_groups))
    @torch.no_grad()
    def update(self,losses:torch.Tensor,groups:torch.Tensor):
        for g in range(len(self.weights)):
            m=groups==g
            if m.any(): self.moving[g]=self.ema*self.moving[g]+(1-self.ema)*losses[m].mean()
        w=self.weights*torch.exp(self.eta*self.moving)
        w=w.clamp(self.min_weight,self.max_weight); self.weights.copy_(w/w.sum())
    def weighted(self,losses:torch.Tensor,groups:torch.Tensor)->torch.Tensor:
        vals=[]
        for g in range(len(self.weights)):
            m=groups==g
            vals.append(losses[m].mean() if m.any() else losses.new_zeros(()))
        return (torch.stack(vals)*self.weights).sum()
