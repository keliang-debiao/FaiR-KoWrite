from __future__ import annotations
import torch
from torch import nn

class SequenceMixer(nn.Module):
    """Mamba-2 when installed; deterministic GRU fallback for smoke/CPU validation."""
    def __init__(self,d_model:int,d_state:int=64,d_conv:int=4,expand:int=2,bidirectional:bool=False):
        super().__init__(); self.backend="gru_fallback"
        try:
            from mamba_ssm import Mamba2
            self.core=Mamba2(d_model=d_model,d_state=d_state,d_conv=d_conv,expand=expand)
            self.backend="mamba2"
        except Exception:
            self.core=nn.GRU(d_model,d_model,batch_first=True,bidirectional=bidirectional)
            self.proj=nn.Linear(d_model*(2 if bidirectional else 1),d_model)
    def forward(self,x:torch.Tensor)->torch.Tensor:
        if self.backend=="mamba2": return self.core(x)
        y,_=self.core(x); return self.proj(y)
