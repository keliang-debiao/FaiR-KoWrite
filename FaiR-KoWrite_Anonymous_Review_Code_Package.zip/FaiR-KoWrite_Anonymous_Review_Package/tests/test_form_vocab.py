from fairkowrite.data.form_vocab import JamoByteTokenizer,VOCAB

def test_vocab_size_and_hangul():
 t=JamoByteTokenizer(); assert len(VOCAB)==331; ids=t.encode('한국어 글쓰기.'); assert len(ids)>5; assert all(0<=x<331 for x in ids)
