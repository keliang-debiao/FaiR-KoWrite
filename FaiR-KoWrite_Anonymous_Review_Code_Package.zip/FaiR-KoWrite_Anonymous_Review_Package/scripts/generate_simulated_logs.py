#!/usr/bin/env python3
from pathlib import Path
import random

TARGET = [0.807, 0.818, 0.824, 0.810, 0.821]
SEEDS = [2026, 2027, 2028, 2029, 2030]
MARKERS = ["SIMULATED_REFERENCE_LOG=TRUE", "NOT_MEASURED_OUTPUT=TRUE", "PURPOSE=AI_WORKFLOW_GUIDANCE_ONLY"]

def main() -> None:
    out = Path("logs/simulated")
    out.mkdir(parents=True, exist_ok=True)
    for fold, target in enumerate(TARGET, 1):
        for seed in SEEDS:
            rng = random.Random(fold * 10000 + seed)
            qwk = target + rng.uniform(-0.003, 0.003)
            mae = [0.431, 0.416, 0.407, 0.427, 0.409][fold - 1] + rng.uniform(-0.006, 0.006)
            lines = MARKERS + [f"RUN=fold{fold}_seed{seed}", "DATA=PLACEHOLDER_NO_RAW_TEXT", "MODEL=FaiR-KoWrite", "EPOCH,TRAIN_LOSS,VAL_QWK,VAL_MAE"]
            for epoch in range(1, 9):
                lines.append(f"{epoch},{1.1/(epoch**0.55)+rng.uniform(-0.02,0.02):.4f},{qwk-0.08/(epoch**0.7)+rng.uniform(-0.002,0.002):.4f},{mae+0.09/(epoch**0.7)+rng.uniform(-0.003,0.003):.4f}")
            lines += [f"BEST_VAL_QWK={qwk:.4f}", f"REFERENCE_FOLD_QWK={target:.3f}", f"REFERENCE_MAE={mae:.3f}", "ARTIFACT_STATUS=SIMULATED_ONLY"]
            (out / f"fold{fold}_seed{seed}.log").write_text("\n".join(lines) + "\n", encoding="utf-8")
    summaries = {
        "baseline_summary.log": ["Qwen3+CORN QWK=0.798", "FaiR-KoWrite QWK=0.816", "DELTA=+0.018"],
        "calibration_summary.log": ["ECE_BEFORE=0.069", "ECE_AFTER=0.031", "MEAN_T=1.34", "COVERAGE_80=0.804", "ACCEPTED_QWK=0.852"],
        "arg_diagnostics_summary.log": ["L1_PROBE_WITHOUT_ADV=0.696", "L1_PROBE_FULL=0.398", "MMD_WITHOUT_ADV=0.082", "MMD_FULL=0.048", "OOD_AUROC=0.812", "NATURAL_AUPR=0.548"],
        "kolla_summary.log": ["FAIRKOWRITE_RHO=0.704", "QWEN3_RHO=0.686", "DELTA_RHO=0.018", "P=0.154"],
        "statistics_summary.log": ["DELTA_QWK=0.018", "CI=[0.010,0.026]", "PERMUTATION_P=0.0004", "HOLM_P=0.0012"],
    }
    for filename, body in summaries.items():
        (out / filename).write_text("\n".join(MARKERS + body + ["ARTIFACT_STATUS=SIMULATED_ONLY"]) + "\n", encoding="utf-8")
    print(f"Created {len(list(out.glob('*.log')))} marked simulated logs")

if __name__ == "__main__":
    main()
