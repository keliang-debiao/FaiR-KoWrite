#!/usr/bin/env python3
from pathlib import Path
import argparse
import csv
import json
from fairkowrite.data.duplicates import candidate_pairs
from fairkowrite.utils.io import read_jsonl

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--kh", default="data/processed/kh_essays.jsonl")
    parser.add_argument("--arg", default="data/processed/arg_essays.jsonl")
    parser.add_argument("--kolla", default="data/external/kolla_v2.jsonl")
    parser.add_argument("--output", default="outputs/audit/near_duplicate_candidates.csv")
    parser.add_argument("--estimated-threshold", type=float, default=0.80)
    parser.add_argument("--exact-threshold", type=float, default=0.90)
    args = parser.parse_args()
    rows = read_jsonl(args.kh) + read_jsonl(args.arg)
    if Path(args.kolla).exists():
        kolla = read_jsonl(args.kolla)
        for row in kolla:
            row = dict(row)
            row["source"] = "KoLLA"
            rows.append(row)
    pairs = candidate_pairs(rows, args.estimated_threshold, permutations=128)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    fields = ["essay_id_a", "essay_id_b", "source_pair", "estimated_jaccard", "exact_jaccard"]
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(pairs)
    report = {
        "candidate_pairs": len(pairs),
        "pairs_at_or_above_exact_threshold": sum(row["exact_jaccard"] >= args.exact_threshold for row in pairs),
        "estimated_threshold": args.estimated_threshold,
        "exact_threshold": args.exact_threshold,
        "output": str(out),
    }
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
