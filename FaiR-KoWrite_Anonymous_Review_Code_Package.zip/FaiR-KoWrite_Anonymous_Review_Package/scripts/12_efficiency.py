#!/usr/bin/env python3
import argparse,json
from fairkowrite.models.model import FaiRKoWrite
from fairkowrite.evaluation.efficiency import parameter_counts

def main():
 p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/main.yaml'); a=p.parse_args(); print(json.dumps({"smoke_fallback":parameter_counts(FaiRKoWrite(semantic_mode='tiny')),"manuscript_reference":"results_reference/computational_efficiency.csv"},indent=2))
if __name__=='__main__': main()
