from fairkowrite.models.model import FaiRKoWrite
from fairkowrite.models.groupdro import LevelGroupDRO
from scripts._synthetic import batch

def test_forward_and_groupdro():
 import torch; torch.set_num_threads(1); m=FaiRKoWrite(semantic_mode='tiny',dim=32); b=batch(b=6,t=2,l=6,fl=8); o=m(**b['inputs']); assert o['probs'].shape==(6,6); g=LevelGroupDRO(); before=g.weights.clone(); losses=o['probs'][:,0]; g.update(losses,b['y']); assert abs(float(g.weights.sum())-1)<1e-6
