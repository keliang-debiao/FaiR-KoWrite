from __future__ import annotations
import torch
from torch import nn

class TinySemanticEncoder(nn.Module):
    def __init__(self,vocab_size:int=4096,hidden:int=128,out_dim:int=384):
        super().__init__(); self.emb=nn.Embedding(vocab_size,hidden,padding_idx=0)
        self.proj=nn.Sequential(nn.Linear(hidden,out_dim),nn.LayerNorm(out_dim))
    def forward(self,input_ids:torch.Tensor,attention_mask:torch.Tensor)->torch.Tensor:
        x=self.emb(input_ids); m=attention_mask.unsqueeze(-1).float()
        pooled=(x*m).sum(1)/m.sum(1).clamp_min(1.0)
        return self.proj(pooled)

class HFSemanticEncoder(nn.Module):
    def __init__(self,model_name:str,revision:str|None,out_dim:int=384):
        super().__init__()
        from transformers import AutoModel
        kwargs={"trust_remote_code":True}
        if revision and not revision.startswith("RESOLVE_"): kwargs["revision"]=revision
        self.model=AutoModel.from_pretrained(model_name,**kwargs)
        hidden=int(self.model.config.hidden_size)
        self.proj=nn.Sequential(nn.Linear(hidden,out_dim),nn.LayerNorm(out_dim))
    def forward(self,input_ids,attention_mask):
        h=self.model(input_ids=input_ids,attention_mask=attention_mask,return_dict=True).last_hidden_state
        m=attention_mask.unsqueeze(-1).float(); pooled=(h*m).sum(1)/m.sum(1).clamp_min(1.)
        return self.proj(pooled)
