from __future__ import annotations
from collections import defaultdict
import hashlib
import itertools
from typing import Iterable
from .conllu import normalize_text

MAX_HASH = (1 << 64) - 1

def shingles(text: str, n: int = 5) -> set[str]:
    value = normalize_text(text)
    if len(value) < n:
        return {value}
    return {value[i:i+n] for i in range(len(value)-n+1)}

def exact_jaccard(a: set[str], b: set[str]) -> float:
    union = len(a | b)
    return len(a & b) / union if union else 1.0

def minhash_signature(items: set[str], permutations: int = 128, seed: int = 2026) -> tuple[int, ...]:
    signature = [MAX_HASH] * permutations
    for item in items:
        raw = item.encode("utf-8")
        for index in range(permutations):
            salt = f"{seed}:{index}:".encode("ascii")
            value = int.from_bytes(hashlib.blake2b(salt + raw, digest_size=8).digest(), "big")
            if value < signature[index]:
                signature[index] = value
    return tuple(signature)

def estimated_jaccard(a: tuple[int, ...], b: tuple[int, ...]) -> float:
    return sum(x == y for x, y in zip(a, b)) / len(a)

def candidate_pairs(rows: list[dict], estimated_threshold: float = 0.80, permutations: int = 128) -> list[dict]:
    """Return MinHash-screened pairs.

    The public dataset is small enough for a deterministic all-pairs signature comparison. Raw text is not
    written to output; only IDs and similarity values are returned.
    """
    prepared = []
    for row in rows:
        sh = shingles(row["text"])
        prepared.append((row["essay_id"], row.get("source", "unknown"), sh, minhash_signature(sh, permutations)))
    output = []
    for (id_a, source_a, sh_a, sig_a), (id_b, source_b, sh_b, sig_b) in itertools.combinations(prepared, 2):
        estimate = estimated_jaccard(sig_a, sig_b)
        if estimate >= estimated_threshold:
            output.append({
                "essay_id_a": id_a,
                "essay_id_b": id_b,
                "source_pair": "–".join(sorted([source_a, source_b])),
                "estimated_jaccard": estimate,
                "exact_jaccard": exact_jaccard(sh_a, sh_b),
            })
    return output
