from __future__ import annotations
import torch
import torch.nn.functional as F
from fairkowrite.models.corn import CORNHead

def joint_loss(output:dict,y:torch.Tensor,groupdro,source_y=None,l1_y=None,consistency_probs=None,weights=(.05,.05,.10)):
    per=CORNHead.loss(output["logits"],y,reduction='none')
    groupdro.update(per.detach(),y); total=groupdro.weighted(per,y)
    details={"ordinal_groupdro":float(total.detach())}
    if source_y is not None:
        l=F.cross_entropy(output["source_logits"],source_y); total=total+weights[0]*l; details["source"]=float(l.detach())
    if l1_y is not None:
        valid=l1_y>=0
        if valid.any():
            l=F.cross_entropy(output["l1_logits"][valid],l1_y[valid]); total=total+weights[1]*l; details["l1"]=float(l.detach())
    if consistency_probs is not None:
        p=output["probs"].clamp_min(1e-8); q=consistency_probs.clamp_min(1e-8)
        m=.5*(p+q); l=.5*((p*(p.log()-m.log())).sum(-1)+(q*(q.log()-m.log())).sum(-1)).mean()
        total=total+weights[2]*l; details["consistency"]=float(l.detach())
    return total,details
