from __future__ import annotations
import numpy as np
import torch
from torch import nn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from .corn import CORNHead

class TfidfOrdinalBaseline:
    """Transparent 3–5 character n-gram cumulative ordinal baseline."""
    def __init__(self, max_features: int = 100_000):
        self.vectorizer = TfidfVectorizer(analyzer="char", ngram_range=(3, 5), max_features=max_features, sublinear_tf=True)
        self.models = [LogisticRegression(max_iter=3000, class_weight="balanced") for _ in range(5)]
    def fit(self, texts: list[str], y: np.ndarray):
        x = self.vectorizer.fit_transform(texts)
        for threshold, model in enumerate(self.models):
            active = y >= threshold
            model.fit(x[active], (y[active] > threshold).astype(int))
        return self
    def predict_proba(self, texts: list[str]) -> np.ndarray:
        x = self.vectorizer.transform(texts)
        q = np.column_stack([m.predict_proba(x)[:, 1] for m in self.models])
        q = np.minimum.accumulate(q, axis=1)
        gt = np.cumprod(np.clip(q, 1e-7, 1 - 1e-7), axis=1)
        p = np.column_stack([1 - gt[:, 0], gt[:, :-1] - gt[:, 1:], gt[:, -1]])
        return p / p.sum(1, keepdims=True)

class BiLSTMAttentionBaseline(nn.Module):
    def __init__(self, vocab_size: int, emb_dim: int = 192, hidden: int = 192, num_classes: int = 6):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
        self.encoder = nn.LSTM(emb_dim, hidden, batch_first=True, bidirectional=True)
        self.attention = nn.Linear(hidden * 2, 1)
        self.head = CORNHead(hidden * 2, num_classes)
    def forward(self, ids: torch.Tensor, mask: torch.Tensor) -> dict:
        x, _ = self.encoder(self.embedding(ids))
        score = self.attention(x).squeeze(-1).masked_fill(~mask, -1e4)
        pooled = (torch.softmax(score, -1).unsqueeze(-1) * x).sum(1)
        logits = self.head(pooled)
        return {"logits": logits, "probs": self.head.probabilities(logits)}

class HierarchicalAttentionBaseline(nn.Module):
    def __init__(self, vocab_size: int, emb_dim: int = 128, hidden: int = 128):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
        self.word = nn.GRU(emb_dim, hidden, batch_first=True, bidirectional=True)
        self.word_attention = nn.Linear(hidden * 2, 1)
        self.sentence = nn.GRU(hidden * 2, hidden, batch_first=True, bidirectional=True)
        self.sentence_attention = nn.Linear(hidden * 2, 1)
        self.head = CORNHead(hidden * 2)
    def forward(self, ids: torch.Tensor, token_mask: torch.Tensor, sentence_mask: torch.Tensor) -> dict:
        batch, sentences, tokens = ids.shape
        x, _ = self.word(self.embedding(ids.reshape(batch * sentences, tokens)))
        wm = token_mask.reshape(batch * sentences, tokens)
        wa = torch.softmax(self.word_attention(x).squeeze(-1).masked_fill(~wm, -1e4), -1).unsqueeze(-1)
        sent = (wa * x).sum(1).reshape(batch, sentences, -1)
        doc, _ = self.sentence(sent)
        da = torch.softmax(self.sentence_attention(doc).squeeze(-1).masked_fill(~sentence_mask, -1e4), -1).unsqueeze(-1)
        z = (da * doc).sum(1)
        logits = self.head(z)
        return {"logits": logits, "probs": self.head.probabilities(logits)}
