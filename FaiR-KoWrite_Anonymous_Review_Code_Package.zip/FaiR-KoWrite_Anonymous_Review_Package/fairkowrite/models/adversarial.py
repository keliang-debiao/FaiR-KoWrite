from __future__ import annotations
import torch
from torch import nn

class _GRL(torch.autograd.Function):
    @staticmethod
    def forward(ctx,x,lambd): ctx.lambd=lambd; return x.view_as(x)
    @staticmethod
    def backward(ctx,g): return -ctx.lambd*g,None

def grad_reverse(x,lambd:float): return _GRL.apply(x,lambd)

class Discriminator(nn.Module):
    def __init__(self,dim:int,n_classes:int,hidden:int=128,dropout:float=.2):
        super().__init__(); self.net=nn.Sequential(nn.Linear(dim,hidden),nn.ReLU(),nn.Dropout(dropout),nn.Linear(hidden,n_classes))
    def forward(self,z,grl:float=1.0): return self.net(grad_reverse(z,grl))
