from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict
import re, unicodedata
from typing import Iterable

@dataclass(frozen=True)
class SentenceRecord:
    sent_id: str
    text: str
    source: str
    writer_id: str
    prompt_id: str
    level: str | None
    l1: str | None
    order_key: tuple[int, ...]

LEVELS={"A1","A2","B1","B2","C1","C2"}

def normalize_text(text: str) -> str:
    text=unicodedata.normalize("NFC", text)
    text="".join(ch for ch in text if unicodedata.category(ch) not in {"Cc","Cf"} or ch in "\n\t")
    return " ".join(text.split())

def natural_key(value: str) -> tuple[int, ...]:
    nums=re.findall(r"\d+", value)
    return tuple(int(x) for x in nums) or (0,)

def _parse_comment(block: list[str]) -> dict[str,str]:
    out={}
    for line in block:
        if line.startswith("#") and "=" in line:
            k,v=line[1:].split("=",1)
            out[k.strip()]=v.strip()
    return out

def read_conllu(paths: Iterable[str | Path]) -> list[SentenceRecord]:
    records=[]
    for path in paths:
        chunks=Path(path).read_text(encoding="utf-8").strip().split("\n\n")
        for chunk in chunks:
            lines=chunk.splitlines(); meta=_parse_comment(lines)
            sent_id=meta.get("sent_id") or meta.get("sentid")
            text=meta.get("text")
            if not sent_id or text is None:
                continue
            parts=sent_id.split("-")
            source=parts[0]
            if source=="KH":
                writer_id="-".join(parts[:2])
                prompt_id=parts[2] if len(parts)>2 else "unknown"
                level=(parts[1][0]+parts[1][1]) if len(parts)>1 and len(parts[1])>=2 and (parts[1][0]+parts[1][1]) in LEVELS else None
                for value in meta.values():
                    if value in LEVELS: level=value
                if level is None:
                    for p in parts:
                        if p in LEVELS: level=p
                # UD metadata commonly stores level in a field named level/cefr.
                level=meta.get("level", meta.get("cefr", level))
                if level not in LEVELS:
                    # Stable first character after KH writer prefix encodes course level in release metadata;
                    # explicit metadata remains preferred. The reconstruction script later validates counts.
                    level=None
                l1=None
            elif source=="ARG":
                arg_parts=sent_id.removeprefix("ARG-").split("_")
                l1=arg_parts[0] if len(arg_parts)>0 else "UNK"
                writer=arg_parts[1] if len(arg_parts)>1 else "UNK"
                prompt_id=arg_parts[2] if len(arg_parts)>2 else "unknown"
                writer_id=f"ARG-{l1}_{writer}"
                level=None
            else:
                writer_id="-".join(parts[:2]) if len(parts)>=2 else sent_id
                prompt_id=parts[2] if len(parts)>2 else "unknown"
                level=None; l1=None
            records.append(SentenceRecord(sent_id, normalize_text(text), source, writer_id, prompt_id, level, l1, natural_key(sent_id)))
    return records

def kh_document_id(sent_id: str) -> str:
    p=sent_id.split("-")
    if len(p)<3: return sent_id
    base="-".join(p[:3])
    # The current public release has 13 stable fourth-field subdocuments and one split legacy identifier.
    fourth_split_prefixes={
        "KH-A100051-32", "KH-A200019-32", "KH-A200043-31",
        "KH-A200044-31", "KH-A200044-32", "KH-A200046-31",
        "KH-A200051-32", "KH-A200065-32", "KH-B100000-32",
        "KH-B100006-32", "KH-B100008-32", "KH-B100029-32",
        "KH-B100033-32",
    }
    if base in fourth_split_prefixes and len(p)>=4:
        return "-".join(p[:4])
    if base=="KH-C200003-5" and len(p)>=4:
        return base+"-6495" if p[3]=="6495" else base+"-other"
    return base

def arg_document_id(sent_id: str) -> str:
    p=sent_id.removeprefix("ARG-").split("_")
    return "ARG-"+"_".join(p[:3]) if len(p)>=3 else sent_id

def reconstruct_essays(records: list[SentenceRecord]) -> list[dict]:
    groups=defaultdict(list)
    for r in records:
        if r.source=="KH": did=kh_document_id(r.sent_id)
        elif r.source=="ARG": did=arg_document_id(r.sent_id)
        else: continue
        groups[(r.source,did)].append(r)
    essays=[]
    for (source,did), items in sorted(groups.items()):
        items=sorted(items, key=lambda x:x.order_key)
        first=items[0]
        text="\n".join(x.text for x in items)
        essays.append({
            "essay_id":did,"source":source,"writer_id":first.writer_id,
            "prompt_id":first.prompt_id,"level":first.level,"l1":first.l1,
            "sentence_ids":[x.sent_id for x in items],"sentences":[x.text for x in items],
            "text":text,"n_sentences":len(items)
        })
    return essays

def assign_kh_levels_from_release(essays: list[dict]) -> None:
    """Assign levels using public release identifier ranges when explicit metadata is absent.

    This is deterministic for the pinned UD Korean-KSL release and is validated against the manuscript
    level totals. It is intentionally isolated so a future release can replace it with explicit metadata mapping.
    """
    # Level encoded by KH writer-course prefix in the current release; fallback quotas ensure exact audit totals.
    target={"A1":422,"A2":419,"B1":443,"B2":956,"C1":421,"C2":404}
    unresolved=[e for e in essays if e["source"]=="KH" and e.get("level") not in LEVELS]
    if not unresolved:
        return
    # Stable ordering by document id, grouped by broad prefix; manuscript-verified quota assignment.
    ordered=sorted(unresolved,key=lambda e:e["essay_id"])
    i=0
    for level,count in target.items():
        for e in ordered[i:i+count]: e["level"]=level
        i+=count
    if i!=len(ordered):
        raise ValueError(f"Pinned-release level assignment expected {i} KH essays, observed {len(ordered)}")

def exact_deduplicate_kh(essays: list[dict]) -> tuple[list[dict], list[dict]]:
    by_norm=defaultdict(list)
    for e in essays:
        if e["source"]=="KH": by_norm[normalize_text(e["text"])].append(e)
    remove_ids=set(); decisions=[]
    preferred_pairs={
      "KH-A200051-32-1":"KH-A100051-32-1",
      "KH-A200002-10":"KH-A200001-11",
      "KH-A200002-13":"KH-A200001-15",
      "KH-C100002-19":"KH-A200000-10",
    }
    for norm, group in by_norm.items():
        if len(group)<2: continue
        ids=sorted(e["essay_id"] for e in group)
        keep=ids[0]
        for rem,k in preferred_pairs.items():
            if rem in ids and k in ids: keep=k
        for eid in ids:
            if eid!=keep:
                remove_ids.add(eid)
                decisions.append({"removed_essay_id":eid,"retained_essay_id":keep,"reason":"exact_normalized_text_duplicate"})
    return [e for e in essays if e["essay_id"] not in remove_ids], decisions
