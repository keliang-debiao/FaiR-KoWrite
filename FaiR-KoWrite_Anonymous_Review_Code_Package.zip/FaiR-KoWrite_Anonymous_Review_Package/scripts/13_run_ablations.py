#!/usr/bin/env python3
from pathlib import Path
import argparse
import json
import yaml

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--variants", default="configs/ablations/variants.yaml")
    args = parser.parse_args()
    variants = yaml.safe_load(Path(args.variants).read_text(encoding="utf-8"))["variants"]
    plan = []
    for name, spec in variants.items():
        for fold in range(1, 6):
            for seed in [2026, 2027, 2028, 2029, 2030]:
                plan.append({"variant": name, "outer_fold": fold, "seed": seed, "retrain": True, "overrides": spec})
    out = Path("outputs/ablations")
    out.mkdir(parents=True, exist_ok=True)
    (out / "run_plan.json").write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"runs": len(plan), "all_variants_retrained": True}, indent=2))

if __name__ == "__main__":
    main()
