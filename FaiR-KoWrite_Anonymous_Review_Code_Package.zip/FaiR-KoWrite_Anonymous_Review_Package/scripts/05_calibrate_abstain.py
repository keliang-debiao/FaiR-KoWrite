#!/usr/bin/env python3
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
from fairkowrite.evaluation.calibration import fit_temperature, apply_temperature, selective_metrics
from fairkowrite.evaluation.metrics import metric_bundle, ece

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="outputs/oof/crossfitted_validation_logits.csv")
    parser.add_argument("--threshold", type=float, default=0.571)
    args = parser.parse_args()
    path = Path(args.input)
    if not path.exists():
        raise SystemExit("Cross-fitted validation logits required; outer-test logits must not tune calibration.")
    df = pd.read_csv(path)
    logits = df[[f"logit_{i}" for i in range(6)]].to_numpy()
    y = df.label.to_numpy()
    temperature = fit_temperature(logits, y)
    probs = apply_temperature(logits, temperature)
    uncertainty = -(probs * np.log(probs.clip(1e-12, 1))).sum(1) / np.log(6)
    report = {
        "temperature": temperature,
        "ece": ece(y, probs),
        "selective": selective_metrics(y, probs, uncertainty, args.threshold, metric_bundle),
    }
    out = Path("outputs/calibration")
    out.mkdir(parents=True, exist_ok=True)
    (out / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
