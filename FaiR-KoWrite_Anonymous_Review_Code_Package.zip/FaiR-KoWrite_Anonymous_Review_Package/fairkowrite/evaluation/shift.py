from __future__ import annotations
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,balanced_accuracy_score,f1_score,roc_auc_score,average_precision_score
from sklearn.model_selection import GroupKFold,cross_val_predict
from scipy.spatial.distance import cdist

def rbf_mmd(x,y,gamma=None):
    x=np.asarray(x); y=np.asarray(y); z=np.vstack([x,y]);
    if gamma is None:
        d=cdist(z,z,'sqeuclidean'); gamma=1/(np.median(d[d>0])+1e-12)
    kxx=np.exp(-gamma*cdist(x,x,'sqeuclidean')).mean(); kyy=np.exp(-gamma*cdist(y,y,'sqeuclidean')).mean(); kxy=np.exp(-gamma*cdist(x,y,'sqeuclidean')).mean()
    return float(max(kxx+kyy-2*kxy,0))
def writer_heldout_probe(z,labels,writers,n_splits=5):
    cv=GroupKFold(n_splits=n_splits); clf=LogisticRegression(max_iter=2000,class_weight='balanced')
    pred=cross_val_predict(clf,z,labels,groups=writers,cv=cv)
    return {"accuracy":float(accuracy_score(labels,pred)),"balanced_accuracy":float(balanced_accuracy_score(labels,pred)),"macro_f1":float(f1_score(labels,pred,average='macro'))}
def ood_metrics(y,score):
    return {"auroc":float(roc_auc_score(y,score)),"aupr":float(average_precision_score(y,score)),"prevalence":float(np.mean(y))}
