#!/usr/bin/env python3
import argparse
import json
from fairkowrite.evaluation.robustness import transform

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--text", default="저는 한국어를 공부합니다.\n매일 글을 씁니다.")
    args = parser.parse_args()
    names = ["nfc_nfd", "linebreak_removal", "punct_style", "spacing_deletion", "jamo_substitution", "sentence_reordering", "truncation"]
    print(json.dumps({name: transform(args.text, name, 0.2) for name in names}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
