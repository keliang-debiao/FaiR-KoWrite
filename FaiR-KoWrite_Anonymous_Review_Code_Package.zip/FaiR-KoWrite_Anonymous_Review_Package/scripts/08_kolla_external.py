#!/usr/bin/env python3
from pathlib import Path
import argparse,pandas as pd,json
from scipy.stats import spearmanr

def main():
 p=argparse.ArgumentParser(); p.add_argument('--predictions',default='outputs/external/kolla_frozen_predictions.csv'); p.add_argument('--config',default='configs/main.yaml'); a=p.parse_args(); path=Path(a.predictions)
 if not path.exists(): raise SystemExit('Frozen KoLLA predictions required. KoLLA must not be used for model selection.')
 d=pd.read_csv(path); rho,pv=spearmanr(d.predicted_score,d.total_rubric); print(json.dumps({"spearman_rho":rho,"p":pv,"n":len(d)},indent=2))
if __name__=='__main__': main()
