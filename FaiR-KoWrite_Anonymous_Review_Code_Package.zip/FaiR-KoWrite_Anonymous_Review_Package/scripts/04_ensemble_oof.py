#!/usr/bin/env python3
from pathlib import Path
import argparse,pandas as pd

def main():
 p=argparse.ArgumentParser(); p.add_argument('--input',default='outputs/cv'); p.add_argument('--output',default='outputs/oof'); a=p.parse_args(); files=list(Path(a.input).glob('fold*_seed*_predictions.csv'))
 if not files: raise SystemExit('No real fold-seed prediction files found.')
 df=pd.concat([pd.read_csv(x) for x in files]); prob=[f'prob_{i}' for i in range(6)]; keys=['essay_id','writer_id','outer_fold','label']; out=df.groupby(keys,as_index=False)[prob].mean(); Path(a.output).mkdir(parents=True,exist_ok=True); out.to_csv(Path(a.output)/'five_seed_averaged_oof.csv',index=False); print(len(out))
if __name__=='__main__': main()
