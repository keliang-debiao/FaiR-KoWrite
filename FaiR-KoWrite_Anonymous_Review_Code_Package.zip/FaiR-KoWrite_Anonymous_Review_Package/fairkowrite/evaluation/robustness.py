from __future__ import annotations
import random, unicodedata

def transform(text:str,name:str,severity:float,seed:int=2026)->str:
    rng=random.Random(seed); chars=list(text)
    if name=='nfc_nfd': return unicodedata.normalize('NFD',text)
    if name=='linebreak_removal': return text.replace('\n',' ')
    if name=='punct_style': return text.replace('.', '。').replace(',', '，')
    if name=='spacing_deletion': return ''.join(c for c in chars if not(c.isspace() and rng.random()<severity))
    if name=='jamo_substitution':
        return ''.join(('ㄱ' if rng.random()<severity and '가'<=c<='힣' else c) for c in chars)
    if name=='sentence_reordering':
        s=[x for x in text.split('\n') if x]; rng.shuffle(s); return '\n'.join(s)
    if name=='truncation': return text[:max(1,int(len(text)*(1-severity)))]
    raise ValueError(name)
