from __future__ import annotations
import time, torch

def parameter_counts(model):
    return {"total":sum(p.numel() for p in model.parameters()),"trainable":sum(p.numel() for p in model.parameters() if p.requires_grad)}
def benchmark(model,inputs,repeats=10):
    model.eval();
    with torch.no_grad():
        for _ in range(2): model(**inputs)
        t=time.perf_counter()
        for _ in range(repeats): model(**inputs)
    return (time.perf_counter()-t)*1000/repeats
