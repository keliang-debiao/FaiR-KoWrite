from __future__ import annotations
import torch
from torch import nn

class CrossGatedBilinearFusion(nn.Module):
    def __init__(self,dim:int=384,dropout:float=.1):
        super().__init__()
        self.bilinear=nn.Bilinear(dim,dim,dim,bias=False)
        self.gate=nn.Linear(dim*2,dim)
        self.s=nn.Linear(dim,dim); self.f=nn.Linear(dim,dim); self.b=nn.Linear(dim,dim)
        self.norm=nn.LayerNorm(dim); self.drop=nn.Dropout(dropout)
    def forward(self,s:torch.Tensor,f:torch.Tensor)->tuple[torch.Tensor,torch.Tensor]:
        b=torch.tanh(self.bilinear(s,f)); g=torch.sigmoid(self.gate(torch.cat([s,f],-1)))
        h=g*self.s(s)+(1-g)*self.f(f)+self.b(b)
        return self.drop(self.norm(h)),g
