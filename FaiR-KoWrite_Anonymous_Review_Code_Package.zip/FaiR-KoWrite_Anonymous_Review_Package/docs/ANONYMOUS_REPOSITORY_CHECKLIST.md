# Anonymous repository submission checklist

- [ ] Repository title and description contain no author or institution identifiers.
- [ ] `python scripts/verify_repository.py` passes.
- [ ] Exact experiment-used writer fold manifest replaces the reference manifest.
- [ ] `python scripts/verify_repository.py --strict-submission` passes.
- [ ] Model revisions are immutable commit hashes, not branches or `main`.
- [ ] Real OOF predictions include all 3,065 KH essays once and only once.
- [ ] Five seed probabilities are averaged before primary metrics.
- [ ] Calibration uses only cross-fitted validation logits.
- [ ] ARG carries no proficiency pseudo-labels.
- [ ] KoLLA predictions are generated after protocol lock.
- [ ] Simulated logs remain plainly marked and are not cited as measured evidence.
- [ ] Raw learner text, private metadata, weights, tokens, and host paths are absent.
- [ ] Package checksums are regenerated after final source edits and verified.
